'use client'

import Link from 'next/link'
import Image from 'next/image'
import hero from '@/assets/hero.jpg'
import { CarouselSection, HighlightCard } from '@/components/CarouselSection'
import { LiveNotice } from '@/components/LiveNotice'
import { StatusMessage } from '@/components/StatusMessage'
import { Poster } from '@/components/ui'
import { useHome } from '@/lib/useRemote'

const stats = [
  { value: '20+', label: 'Locales', spoken: 'Más de 20 locales' },
  { value: '28', label: 'Años de sabor', spoken: '28 años de sabor' },
  { value: '50+', label: 'Platos en carta', spoken: 'Más de 50 platos en carta' },
  { value: '5★', label: 'Calificación', spoken: 'Calificación de 5 estrellas' },
]

const cardText = (title: string, subtitle: string) => (
  <span className="block p-4">
    <span className="mb-1 block font-display text-base font-bold text-ink">{title}</span>
    <span className="block text-sm leading-relaxed text-muted">{subtitle}</span>
  </span>
)

export function HomeContent() {
  const { data: home, status, reload } = useHome()
  const showsVisible = !home.live || home.shows.length > 0
  const promosVisible = !home.live || home.promotions.length > 0

  return (
    <>
      <div className="on-dark relative flex min-h-[580px] items-end justify-center overflow-hidden bg-charcoal text-center">
        {home.hero.url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={home.hero.url} alt="" className="absolute inset-0 size-full object-cover object-top opacity-90" />
        ) : (
          <Image src={hero} alt="" priority fill sizes="100vw" className="object-cover object-top opacity-90" />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent from-40% to-[rgba(10,5,5,0.82)]" aria-hidden="true" />
        <div className="relative z-10 mx-auto w-full max-w-3xl px-6 pb-14">
          <h1 className="sr-only">Rústica Shows. Con los mejores artistas en vivo</h1>
          <Link
            href="/menu/"
            className="hero-cta inline-flex min-h-12 items-center rounded-xl border-2 px-8 py-3.5 text-base font-bold transition-colors"
          >
            Ver Menú
          </Link>
        </div>
      </div>

      <div className="bg-red px-6 py-6">
        <ul className="mx-auto grid max-w-5xl grid-cols-2 gap-4 text-center text-white md:grid-cols-4">
          {stats.map(stat => (
            <li key={stat.label}>
              <span className="sr-only">{stat.spoken}</span>
              <span aria-hidden="true">
                <span className="block font-display text-3xl font-bold">{stat.value}</span>
                <span className="block text-sm uppercase tracking-wider">{stat.label}</span>
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="bg-cream px-6 py-16">
        <div className="mx-auto max-w-6xl space-y-14">
          <LiveNotice status={status} what="promociones y shows" onRetry={reload} />
          {promosVisible && (
            <CarouselSection title="Promociones" href="/promociones/" linkLabel="Ver todas" noun="promociones">
              {home.promotions.map(item => (
                <HighlightCard key={item.key} href="/promociones/">
                  <Poster art={item.art} />
                  {cardText(item.shortTitle, item.shortSubtitle)}
                </HighlightCard>
              ))}
            </CarouselSection>
          )}

          {showsVisible && (
            <CarouselSection title="Shows" href="/shows/" linkLabel="Ver todos" noun="shows">
              {home.shows.map(show => (
                <HighlightCard key={show.key} href="/shows/">
                  <Poster art={show.art} />
                  {cardText(show.artist, `${show.dateLabel} · ${show.location}`)}
                </HighlightCard>
              ))}
            </CarouselSection>
          )}
          {home.live && !promosVisible && !showsVisible && (
            <StatusMessage kind="info">Pronto publicaremos nuevas promociones y shows.</StatusMessage>
          )}
        </div>
      </div>
    </>
  )
}
