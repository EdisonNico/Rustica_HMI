import { StatusMessage } from './StatusMessage'
import type { RemoteStatus } from '@/lib/useRemote'

/**
 * Estado de la conexión con la API. Mientras carga se ve el contenido de respaldo
 * y un aviso discreto (role="status", se anuncia sin mover el foco). Si falla, un
 * mensaje con texto, icono y botón para reintentar; el color no es lo único que informa.
 */
export function LiveNotice({ status, what, onRetry }: { status: RemoteStatus; what: string; onRetry: () => void }) {
  return (
    <>
      <div role="status" className="text-center text-sm text-muted empty:hidden">
        {status === 'loading' ? `Actualizando ${what}…` : null}
      </div>
      {status === 'error' && (
        <div className="mx-auto mb-6 max-w-2xl">
          <StatusMessage kind="info">
            No pudimos actualizar {what}; te mostramos la última información disponible.{' '}
            <button type="button" onClick={onRetry} className="min-h-11 cursor-pointer font-bold text-brand underline underline-offset-4">
              Reintentar
            </button>
          </StatusMessage>
        </div>
      )}
    </>
  )
}
