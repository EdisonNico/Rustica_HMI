/**
 * Modelos que usa la interfaz y su conversión desde (a) los archivos de src/data,
 * que sirven de respaldo, y (b) las respuestas de la API.
 */
import hero from '@/assets/hero.jpg'
import { categories as staticCategories, dishes as staticDishes, type Dish } from '@/data/menu'
import { branchGroups } from '@/data/locations'
import { showDescriptions, shows as staticShows } from '@/data/shows'
import { promotions as staticPromotions } from '@/data/promotions'
import { promotionHighlights } from '@/data/highlights'
import { news as staticNews } from '@/data/news'
import { PROMOTIONS_BOARD, SHOW_BOARDS } from '@/lib/boards'
import { formatDate } from '@/lib/format'

/* ───────── Tipos de la interfaz ───────── */

/** Afiche: una imagen propia (API) o el recorte de una hoja de afiches (respaldo). */
export type PosterArt =
  | { kind: 'url'; url: string }
  | { kind: 'board'; src: string; size: string; position: string }

export interface BranchGroup {
  label: string
  branches: Array<{ value: string; label: string }>
}
export interface CategoryView {
  value: string
  label: string
  description: string
}
export type DishView = Omit<Dish, 'category'> & { category: string }

export interface ShowView {
  key: string
  artist: string
  dateLabel: string
  timeLabel?: string
  location: string
  description: string[]
  art: PosterArt | null
}
export interface PromotionView {
  key: string
  title: string
  subtitle: string
  price?: string
  details: string[]
  terms: string[]
  shortTitle: string
  shortSubtitle: string
  art: PosterArt | null
}
export interface NewsView {
  key: string
  date: string
  cat: string
  title: string
  excerpt: string
  img: string | null
}
export interface HeroView {
  /** Imagen local (respaldo) o URL de la API */
  local?: typeof hero
  url?: string
  alt: string
}
export interface MenuView {
  categories: CategoryView[]
  dishes: DishView[]
}
export interface HomeView {
  hero: HeroView
  promotions: PromotionView[]
  shows: ShowView[]
  /** true cuando los datos vienen de la API: una lista vacía significa "no hay", no "no cargó" */
  live: boolean
}

/* ───────── Respaldo (src/data) ───────── */

export const FALLBACK_BRANCHES: BranchGroup[] = branchGroups
export const FALLBACK_MENU: MenuView = { categories: staticCategories, dishes: staticDishes }
export const FALLBACK_HERO: HeroView = { local: hero, alt: '' }

const boardArt = (src: string, size: string, position: string): PosterArt => ({ kind: 'board', src, size, position })

export const FALLBACK_SHOWS: ShowView[] = staticShows.map(show => ({
  key: `${show.artist}-${show.date}`,
  artist: show.artist,
  dateLabel: show.date,
  timeLabel: '09:00 p. m.',
  location: show.location,
  description: showDescriptions[`${show.artist}|${show.date}`] ?? [],
  art: boardArt(SHOW_BOARDS[show.sheet], show.size, show.position),
}))

export const FALLBACK_PROMOTIONS: PromotionView[] = staticPromotions.map(item => ({
  key: item.title,
  title: item.title,
  subtitle: item.subtitle,
  price: item.price,
  details: item.details,
  terms: item.terms ?? [],
  shortTitle: item.title,
  shortSubtitle: item.subtitle,
  art: boardArt(PROMOTIONS_BOARD.src, PROMOTIONS_BOARD.size, item.position),
}))

export const FALLBACK_HOME: HomeView = {
  hero: FALLBACK_HERO,
  promotions: promotionHighlights.map(item => ({
    key: item.title,
    title: item.title,
    subtitle: item.subtitle,
    details: [],
    terms: [],
    shortTitle: item.title,
    shortSubtitle: item.subtitle,
    art: boardArt(PROMOTIONS_BOARD.src, PROMOTIONS_BOARD.size, item.position),
  })),
  shows: FALLBACK_SHOWS.slice(0, 6),
  live: false,
}

export const FALLBACK_NEWS: NewsView[] = staticNews.map(item => ({
  key: `${item.date}-${item.title}`,
  date: item.date,
  cat: item.cat,
  title: item.title,
  excerpt: item.excerpt,
  img: item.img,
}))

/* ───────── Respuestas de la API ───────── */

export interface ApiBranch { slug: string; name: string; zone: string | null }
export interface ApiCategory { slug: string; name: string; description: string | null }
export interface ApiDish {
  id: number; name: string; description: string | null; priceLabel: string; imageUrl: string | null
  category: string; badge: string | null; featured: boolean
}
export interface ApiMenu { categories: ApiCategory[]; dishes: ApiDish[] }
export interface ApiShow {
  id: number; artist: string; date: string; time: string | null; location: string
  imageUrl: string | null; description: string[] | null
}
export interface ApiPromotion {
  id: number; title: string; subtitle: string | null; priceLabel: string | null; imageUrl: string | null
  details: string[] | null; terms: string[] | null; shortTitle: string | null; shortSubtitle: string | null
}
export interface ApiNews { id: number; date: string | null; category: string; title: string; excerpt: string; imageUrl: string | null }
export interface ApiHome {
  hero: { imageUrl: string | null; alt: string | null }
  promotions: ApiPromotion[]
  shows: ApiShow[]
}

/** "21:00:00" → "9:00 p. m." */
export function formatTime(value: string | null | undefined) {
  if (!value) return undefined
  const [h, m] = value.split(':').map(Number)
  if (Number.isNaN(h) || Number.isNaN(m)) return undefined
  const suffix = h >= 12 ? 'p. m.' : 'a. m.'
  const hour = h % 12 === 0 ? 12 : h % 12
  return `${hour}:${String(m).padStart(2, '0')} ${suffix}`
}

const urlArt = (url: string | null): PosterArt | null => (url ? { kind: 'url', url } : null)

export function groupBranches(list: ApiBranch[]): BranchGroup[] {
  const groups = new Map<string, BranchGroup>()
  for (const item of list) {
    const label = item.zone ?? 'Otras sedes'
    if (!groups.has(label)) groups.set(label, { label, branches: [] })
    groups.get(label)!.branches.push({ value: item.slug, label: item.name })
  }
  return [...groups.values()]
}

export const toMenu = (raw: ApiMenu): MenuView => ({
  categories: raw.categories.map(c => ({ value: c.slug, label: c.name, description: c.description ?? '' })),
  dishes: raw.dishes.map(d => ({
    id: d.id,
    name: d.name,
    description: d.description ?? '',
    price: d.priceLabel,
    image: d.imageUrl ?? '',
    category: d.category,
    badge: d.badge ?? undefined,
    featured: d.featured,
  })),
})

export const toShow = (s: ApiShow): ShowView => ({
  key: String(s.id),
  artist: s.artist,
  dateLabel: formatDate(s.date),
  timeLabel: formatTime(s.time),
  location: s.location,
  description: s.description ?? [],
  art: urlArt(s.imageUrl),
})

export const toPromotion = (p: ApiPromotion): PromotionView => ({
  key: String(p.id),
  title: p.title,
  subtitle: p.subtitle ?? '',
  price: p.priceLabel ?? undefined,
  details: p.details ?? [],
  terms: p.terms ?? [],
  shortTitle: p.shortTitle || p.title,
  shortSubtitle: p.shortSubtitle || p.subtitle || '',
  art: urlArt(p.imageUrl),
})

export const toNews = (n: ApiNews): NewsView => ({
  key: String(n.id),
  date: n.date ?? '',
  cat: n.category,
  title: n.title,
  excerpt: n.excerpt,
  img: n.imageUrl,
})

export const toHome = (raw: ApiHome): HomeView => ({
  hero: raw.hero?.imageUrl ? { url: raw.hero.imageUrl, alt: raw.hero.alt ?? '' } : FALLBACK_HERO,
  promotions: raw.promotions.map(toPromotion),
  shows: raw.shows.map(toShow),
  live: true,
})
