'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { apiEnabled, apiGet } from './api'
import {
  FALLBACK_BRANCHES,
  FALLBACK_HOME,
  FALLBACK_MENU,
  FALLBACK_NEWS,
  FALLBACK_PROMOTIONS,
  FALLBACK_SHOWS,
  groupBranches,
  toHome,
  toMenu,
  toNews,
  toPromotion,
  toShow,
  type ApiBranch,
  type ApiHome,
  type ApiMenu,
  type ApiNews,
  type ApiPromotion,
  type ApiShow,
} from './content'

/**
 * idle    → la API no está configurada: se muestran los datos de respaldo
 * loading → pidiendo datos (mientras tanto se ve el respaldo o lo último cargado)
 * live    → datos de la API
 * error   → la API no respondió: se muestra el respaldo
 */
export type RemoteStatus = 'idle' | 'loading' | 'live' | 'error'

const FRESH_MS = 60_000
const cache = new Map<string, { at: number; raw: unknown }>()

interface Remote<T> {
  data: T
  status: RemoteStatus
  reload: () => void
}

function useRemote<T, R>(path: string | null, fallback: T, map: (raw: R) => T): Remote<T> {
  const fallbackRef = useRef(fallback)
  const mapRef = useRef(map)
  const [attempt, setAttempt] = useState(0)
  const [state, setState] = useState<{ data: T; status: RemoteStatus }>({
    data: fallback,
    status: path && apiEnabled ? 'loading' : 'idle',
  })

  useEffect(() => {
    if (!path || !apiEnabled) {
      setState({ data: fallbackRef.current, status: 'idle' })
      return
    }
    const cached = attempt === 0 ? cache.get(path) : undefined
    if (cached && Date.now() - cached.at < FRESH_MS) {
      setState({ data: mapRef.current(cached.raw as R), status: 'live' })
      return
    }
    const controller = new AbortController()
    // Se conserva lo último mostrado para que la pantalla no se vacíe mientras llega la respuesta
    setState(prev => ({ data: prev.data, status: 'loading' }))
    apiGet<R>(path, controller.signal)
      .then(raw => {
        cache.set(path, { at: Date.now(), raw })
        setState({ data: mapRef.current(raw), status: 'live' })
      })
      .catch(() => {
        if (controller.signal.aborted) return
        setState(prev => ({ data: prev.data, status: 'error' }))
      })
    return () => controller.abort()
  }, [path, attempt])

  const reload = useCallback(() => setAttempt(n => n + 1), [])
  return { ...state, reload }
}

export const useBranches = () =>
  useRemote<typeof FALLBACK_BRANCHES, ApiBranch[]>('/api/branches', FALLBACK_BRANCHES, groupBranches)

/** Carta de una sede. Con la API apagada devuelve la carta completa de respaldo. */
export const useMenu = (branch: string) =>
  useRemote('/api/menu?branch=' + encodeURIComponent(branch), FALLBACK_MENU, (raw: ApiMenu) => toMenu(raw))

export const useHome = () => useRemote('/api/home', FALLBACK_HOME, (raw: ApiHome) => toHome(raw))

export const useShows = () => useRemote('/api/shows', FALLBACK_SHOWS, (raw: ApiShow[]) => raw.map(toShow))

export const usePromotions = () =>
  useRemote('/api/promotions', FALLBACK_PROMOTIONS, (raw: ApiPromotion[]) => raw.map(toPromotion))

export const useNews = () => useRemote('/api/news', FALLBACK_NEWS, (raw: ApiNews[]) => raw.map(toNews))
